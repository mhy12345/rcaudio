# rcaudio : A Realtime Audio Recording & Analyze Script

## Introduction 

rcaudio is a realtime audio recording script, it provide easy way to record via microphone and then analyze.

rcaudio provide APIs to get:

* The raw audio data
* Volume
* Beat Information

